


 
 
    
    document.getElementById('btn1').addEventListener('click', function() {
        alert('Кнопка №1 была нажата');
    });
    document.getElementById('btn2').addEventListener('click', function() {
        alert('Кнопка №2 была нажата');
    });
    document.getElementById('btn3').addEventListener('click', function() {
        alert('Кнопка №3 была нажата');
    });


 