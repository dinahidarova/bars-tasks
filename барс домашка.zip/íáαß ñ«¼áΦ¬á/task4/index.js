 
    const secretCode = '+7952812';

    let enteredCode = '';

    document.getElementById('code-input').addEventListener('keydown', function(event) {
  
      enteredCode += event.key;

      enteredCode = event.target.value;
      if (enteredCode === secretCode) {
        
        document.getElementById('message').style.display = 'block';
      }
    });